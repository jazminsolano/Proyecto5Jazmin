// app.js
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();

// Configuración de mongoose
mongoose.connect('mongodb://localhost:27017/Proyecto5', { useNewUrlParser: true, useUnifiedTopology: true });

// Definir el esquema de datos para Registro de Datos
const registroDatosSchema = new mongoose.Schema({
  ID:Number,
  Cliente: String,
  Gmail: String,
  Codigo: Number,
  cantidad: Number, 
});

const RegistroDatos = mongoose.model('RegistroDatos', registroDatosSchema);

// Definir el esquema de datos para Registro de Venta
const registroVentaSchema = new mongoose.Schema({
  Cliente: String,
  producto: String,
  cantidad: Number,
  precio: Number,
  // Agrega más campos según tus necesidades
});

const RegistroVenta = mongoose.model('RegistroVenta', registroVentaSchema);

app.set('view engine', 'pug');
app.use(bodyParser.urlencoded({ extended: true }));

// Rutas para el formulario de Registro de Datos
app.get('/registro-datos', (req, res) => {
  res.render('registro-datos');
});

app.post('/registro-datos', async (req, res) => {
  try {
    const nuevoRegistro = new RegistroDatos(req.body);
    await nuevoRegistro.save();
    res.redirect('/registro-datos');
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// Rutas para el formulario de Registro de Venta
app.get('/registro-venta', (req, res) => {
  res.render('registro-venta');
});

app.post('/registro-venta', async (req, res) => {
  try {
    const nuevaVenta = new RegistroVenta(req.body);
    await nuevaVenta.save();
    res.redirect('/registro-venta');
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// Inicia el servidor
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`Servidor en ejecución en http://localhost:${PORT}`);
});

